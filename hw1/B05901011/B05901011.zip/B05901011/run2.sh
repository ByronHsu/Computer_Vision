echo "Start running 2a"
python3 hw1-1.py 2a
python3 hw1-2.py 2a
echo "Start running 2b"
python3 hw1-1.py 2b
python3 hw1-2.py 2b
echo "Start running 2c"
python3 hw1-1.py 2c
python3 hw1-2.py 2c